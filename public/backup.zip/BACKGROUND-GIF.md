# TRAVA. background GIF

The default background is `trava-bg.gif` in this folder. Replace that file with another GIF using **the same filename** to change the default for everyone. The CSS on all pages fills the available screen with `background-size: cover`, so uploads with a different aspect ratio are cropped at the edges rather than stretched.

For a single reusable export across desktop and phone screens, use a **1200 × 1200 px square GIF**, keep important artwork near the center, and keep the file under **15 MB** for reasonable loading. The current default file is **500 × 700 px**; it still works, but can look soft on larger screens.

On the login page, use **Background** to choose a GIF and see its actual pixel dimensions. This saves an override in that browser and applies it to all TRAVA. pages served from the same site address. **Use default GIF** removes the override. Browser uploads do not replace the shared file on the server; replace `trava-bg.gif` to change the default for all visitors.
